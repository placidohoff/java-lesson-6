/**
 * Represents a program for simulating space travel.
 */
package planets.main;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;
import javax.xml.parsers.ParserConfigurationException;

import assignment.files.xml.XmlMaker;
import assignment.poi.PoiUtility;
import planets.bodies.PlanetaryBodiesContainer;
import planets.transportation.VehiclesContainer;
import planets.util.AppConfig;
import planets.util.PlanetaryConstants;
import planets.util.PlanetaryDialog;
import planets.util.SpaceCalculate;
import java.util.Date;

// import edu.ccri.assignment.planets.test.dialog.PlanetaryDialog;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Represents a program for simulating space travel.
 */
public class SpaceTravel {

    // private static PlanetaryDialog planetDialog = new PlanetaryDialog("Welcome to
    // the Space Calculator");

    private static PlanetaryDialog planetDialog = new PlanetaryDialog("Welcome to the Space Calculator");

    @SuppressWarnings("unused")
    private static int numberOfIterations = 0;

    // Assign values from the app.properties file to the constants being used:
    private static final String FILE_PATH = AppConfig.getPlanetsExcelSheet();
    private static final String EXPORT_PATH = AppConfig.getOutputFilePath();
    private static final int PLANETS_SHEET_NUM = Integer.parseInt(AppConfig.getPlanetsSheetNumber());
    private static final int VEHICLES_SHEET_NUM = Integer.parseInt(AppConfig.getVehiclesSheetNumber());

    private static final String CONTACT_INFO_FILEPATH_INPUT = AppConfig.getInputContactFileName();

    private static final String CONTACT_INFO_FILEPATH_OUTPUT = AppConfig.getOutputContactFilePath();

    private static List<String[]> listOfPlanetsExcelData;
    private static List<String[]> listOfVehiclesExcelData;
    private static List<String[]> listOfContactInfoData;

    private static List<String> listOfPlanetNames;
    private static List<String> listOfVehicleNames;

    /**
     * Container for storing planetary bodies.
     */
    public static PlanetaryBodiesContainer planetaryBodiesContainer;

    /**
     * Container for storing transportation vehicles.
     */
    public static VehiclesContainer vehiclesContainer;

    /**
     * Total travel time for all journeys.
     */
    public static double totalTravelTime;

    /**
     * Total wages for all journeys.
     */
    public static double totalWages;

    /**
     * Flag indicating whether to continue making journeys.
     */
    public static boolean isContinue = true;

    /**
     * Accumulates the results of each journey.
     */
    public static StringBuilder journeyResults = new StringBuilder("");

    /**
     * Number of iterations.
     */
    public static int numberOfItterations = 0;

    /**
     * List to store the results of all journeys.
     */
    @SuppressWarnings("unchecked")
    public static List<String[]> listOfTotalResults = new ArrayList();

    /**
     * Results of a single journey leg.
     */
    public static List<String> journeyLegResults;

    /**
     * Headers for the Excel table that will hold information about the user's
     * journey.
     */
    public static String[] headersForJourneyDetailsExcelTable = { "Journey Leg", "Transportation Vehicle",
            "Starting Planet",
            "Destination Planet", "Travel Time", "Total Salary Expenses", "Salary per Crew Member", "Total Food Cost",
            "Food Cost per Crew Member" };

    /**
     * Headers for the Excel table that will hold information about the developer's
     * contact information.
     */
    public static String[] headersForContactInfoExcelTable = { "Assignment", "First Name", "Last Name",
            "Student ID", "Email", "Date", "Comments" };

    public static List<String[]> headersForExcelExport;

    private static final Logger logger = LogManager.getLogger(SpaceTravel.class);

    public static String[] resultsOfLeg;

    public static String accuracy;

    public static boolean isAccuracy;



    /**
     * Main method to start the space travel simulation program.
     *
     * @param args Command-line arguments.
     */
    public static void main(String[] args) {

        try {
            PlanetaryConstants.CreateInstance(true);
        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        /**
         *
         */
        listOfPlanetsExcelData = PoiUtility.getData(FILE_PATH, PLANETS_SHEET_NUM);
        /**
         *
         */
        listOfVehiclesExcelData = PoiUtility.getData(FILE_PATH, VEHICLES_SHEET_NUM);
        try {
            listOfContactInfoData = PoiUtility.getDataContactDataFromXML(CONTACT_INFO_FILEPATH_INPUT);
        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            logger.error("Error extracting contact info: ", e.getMessage());

        }

        /**
         *
         */
        planetaryBodiesContainer = new PlanetaryBodiesContainer(listOfPlanetsExcelData);
        vehiclesContainer = new VehiclesContainer(listOfVehiclesExcelData);

        /**
         * Retrieve an alphabetically sorted list from the object holding the list of names of Planetary Bodies
         */
        listOfPlanetNames = planetaryBodiesContainer.getSortedNameList();

        /**
         * Retrieve an alphabetically sorted list from the object holding the list of names of Vehicles
         */
        listOfVehicleNames = vehiclesContainer.getSortedNameList();

        /**
         * Convert the list of Planetary Body names to an array. The array needed is initialized as a number of empty String indexes equal to the strings in the List
         * This conversion is needed in order to be passed to the PlanetDialog for display purposes for the end user to select from
         */
        String[] arrayPlanetNames = new String[listOfPlanetNames.size()];
        listOfPlanetNames.toArray(arrayPlanetNames);

        /**
         * Convert the list of Vehicles names to an array. The array needed is initialized as a number of empty String indexes equal to the strings in the List
         * This conversion is needed in order to be passed to the PlanetDialog for display purposes for the end user to select from
         */
        String[] arrayVehicleNames = new String[listOfVehicleNames.size()];
        listOfVehicleNames.toArray(arrayVehicleNames);

        /**
         * Set configurations for the PlanetDialoog
         */
        planetDialog.setUseStartingPlanet();
        planetDialog.setUseDestinationPlanet();
        planetDialog.setUseTransporationVehicle();
        planetDialog.setUseConversionRate();
        planetDialog.setUseTravelDate();
        planetDialog.setUseAccuracy();


        /**
         * Enter the main loop of the program
         */
        while (isContinue) {
            /**
             * Keeping track of the number of number of journey legs
             */
            numberOfIterations++;

            /**
             * Array used to hold data from the journey
             */
            journeyLegResults = new ArrayList<String>();

            /**
             * Display list of vehicles and planetary body names for the user to select as  their vehicle, starting planet, and destination
             */
            planetDialog.showMultiEditDialog(arrayPlanetNames, arrayVehicleNames);

            String startingPlanet = planetDialog.getStartingPlanetName();
            String destinationPlanet = planetDialog.getDestinationPlanetName();
            String transportationVehicle = planetDialog.getTransportationVechicleName();

            /**
             * User will use a destination planet
             */
            Date departureDate = planetDialog.getTravelDate();

            //Get Accuracy, pass to PlanetaryConstants
            //CAN BE PUT INTO ITS OWN FUNCTION: SetAccuracy(planetDialog.getAccuracty()) and given javadoc comments
            accuracy = planetDialog.getAccuracy();
            isAccuracy = false;

            if(accuracy == "Precise") {
                isAccuracy = true;
            }else if(accuracy == "Estimate") {
                isAccuracy = false;
            }


            // Format for day, month, and year
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");

            double conversionRate = planetDialog.getDollarToEuroConversionRate();

            double travelTimeHours = SpaceCalculate.calculateJourneyHours(startingPlanet, destinationPlanet,
                    transportationVehicle);

            Date arrivalDate = SpaceCalculate.determineArrivalDate(departureDate, travelTimeHours);

            String travelTimeString = SpaceCalculate.getTimeFormattedAsString(travelTimeHours);

            String[] expensesArray = SpaceCalculate.calculateJourneyExpenses(transportationVehicle, travelTimeHours,
                    conversionRate);

            /**
             * StringBuilder used to compile the results for the user
             */
            journeyResults.append("Starting Planet: " + startingPlanet + "\n");
            journeyResults.append("Destination Planet: " + destinationPlanet + "\n");
            journeyResults.append("Transportation Vehicle: " + transportationVehicle + "\n");
            journeyResults.append("Accuracy: " + accuracy + "\n");
            journeyResults.append("\n");
            journeyResults.append("Time:" + "\n");
            journeyResults.append("Travel Time: " + travelTimeString + "\n");
            journeyResults.append("Departure Date: " + dateFormat.format(departureDate) + "\n");
            journeyResults.append("Arrival Date: " + dateFormat.format(arrivalDate) + "\n");
            journeyResults.append("\n");
            journeyResults.append("Expenses:" + "\n");
            journeyResults.append("(USA) Salary per crew member: " + expensesArray[0] + "\n");
            journeyResults.append("(USA) Total Salary Expenses: " + expensesArray[1] + "\n");
            journeyResults.append("(USA) Food Expenses per crew member: " + expensesArray[2] + "\n");
            journeyResults.append("(USA) Total Food Expenses: " + expensesArray[3] + "\n\n");
            journeyResults.append("(UK) Salary per crew member: " + expensesArray[4] + "\n");
            journeyResults.append("(UK) Total Salary Expenses: " + expensesArray[5] + "\n");
            journeyResults.append("(UK) Food Expenses per crew member: " + expensesArray[6] + "\n");
            journeyResults.append("(UK) Total Food Expenses: " + expensesArray[7] + "\n\n");

            journeyResults.append("----------------------------------------------------\n");

            planetDialog.showModalDialog(journeyResults.toString());

            resultsOfLeg = returnArrayOfJourneyLeg(numberOfItterations, startingPlanet, destinationPlanet,
                    transportationVehicle, travelTimeString, expensesArray);

            listOfTotalResults.add(resultsOfLeg);

            /**
             * Asks the user if the want to make another journey.
             * If user chooses to end the journey, the boolean controlling the while loop will be set to false.
             * If the user wants to make another journey, the boolean will remain true.
             */
            int choice = JOptionPane.showConfirmDialog(null, "Do you want to make another journey?", "Another Journey",
                    JOptionPane.YES_NO_OPTION);
            if (choice != JOptionPane.YES_OPTION) {
                /**
                 * Set boolean controlling loop to false
                 */
                isContinue = false;
            } else {
                /**
                 * If the user chooses to make another journey leg
                 * For the next journey leg, we configure the PlanetDialog to allow the user to choose their destination planet and travel date.
                 * The new starting planet gets set to be the previous destination planet. The transportation vehicle remains the same as before.
                 */
                planetDialog.setUseDestinationPlanet();
                planetDialog.setStartingPlanetName(destinationPlanet);
                planetDialog.setTransportationVehicleName(transportationVehicle);
                planetDialog.setDestinationPlanetName(null);
                planetDialog.setTravelDate(arrivalDate);
                planetDialog.setUseTravelDate();
            }
        }


        /**
         * Once the journey is done, we begin the process of generating the output files
         */

        /**
         * Names for the sheets
         */
        List<String> sheetNames = new ArrayList<>();
        sheetNames.add("Space Journey Details");
        sheetNames.add("Developer's Contact Information");

        List<String[]> headersForExportedExcel = new ArrayList<>();
        headersForExportedExcel.add(headersForJourneyDetailsExcelTable);
        headersForExportedExcel.add(headersForContactInfoExcelTable);

        List<List<String[]>> dataCellsForExportedExcel = new ArrayList<>();
        dataCellsForExportedExcel.add(listOfTotalResults);
        List<String[]> contactInfoArray = returnListOfContactInfo(listOfContactInfoData);
        dataCellsForExportedExcel.add(contactInfoArray);



        //CREATE THE EXCEL FILE:
        PoiUtility.createExcelFile(sheetNames, headersForExportedExcel, dataCellsForExportedExcel, EXPORT_PATH);

        //CREATE THE XML FILE:
        XmlMaker xmlMaker = new XmlMaker();

        xmlMaker.CreateXMLFile(dataCellsForExportedExcel, EXPORT_PATH);


    }

    /**
     * Returns an array representing a journey leg with specific details.
     * @param numItterations The number of iterations for the journey leg.
     * @param startingPlanet The starting planet for the journey leg.
     * @param destinationPlanet The destination planet for the journey leg.
     * @param transportationVehicle The transportation vehicle used for the journey leg.
     * @param travelTimeString The time taken for the journey leg.
     * @param expensesArray Array containing expense details.
     * @return Array representing the journey leg with specific details.
     */
    private static String[] returnArrayOfJourneyLeg(int numItterations, String startingPlanet, String destinationPlanet,
                                                    String transportationVehicle, String travelTimeString, String[] expensesArray) {

        String[] resultsArray = new String[9];

        resultsArray[0] = Integer.toString(numItterations + 1);
        resultsArray[1] = transportationVehicle;
        resultsArray[2] = startingPlanet;
        resultsArray[3] = destinationPlanet;
        resultsArray[4] = travelTimeString;
        resultsArray[5] = expensesArray[1];
        resultsArray[6] = expensesArray[0];
        resultsArray[7] = expensesArray[3];
        resultsArray[8] = expensesArray[2];

        return resultsArray;
    }

    /**
     * Returns an array of contact information from the provided data.
     * @param contactInfoData List containing contact information data.
     * @return Array representing contact information.
     */
    private static String[] returnArrayOfContactInfo(List<String[]> contactInfoData) {

        String[] contactInfoArray = new String[6];

        // Assuming contactInfoData contains 6 elements in order

        for (int i = 0; i < 6; i++) {
            contactInfoArray[i] = contactInfoData.get(i)[1];

        }
        return contactInfoArray;
    }

    /**
     * Returns a list of contact information from the provided data.
     * @param contactInfoData List containing contact information data.
     * @return List of arrays representing contact information.
     */
    private static List<String[]> returnListOfContactInfo(List<String[]> contactInfoData) {
        List<String[]> contactInfoList = new ArrayList<>();

        // Assuming contactInfoData contains at least 6 elements
        for (int i = 0; i < 6; i++) {
            if (i < contactInfoData.size() && contactInfoData.get(i) != null && contactInfoData.get(i).length >= 2) {
                String[] contactInfoArray = new String[2];
                contactInfoArray[0] = contactInfoData.get(i)[0]; // Assuming the first element is the key
                contactInfoArray[1] = contactInfoData.get(i)[1]; // Assuming the second element is the value
                contactInfoList.add(contactInfoArray);
            } else {
                // Handle missing or incomplete data
                // You can skip adding this entry or handle it differently based on your
                // requirements
            }
        }

        return contactInfoList;
    }

}
