package planets.main;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.time.LocalDate;

public class SpaceTravelGUI extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Planetary Calculator");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(5);
        grid.setHgap(5);

        // Starting Planet
        Label startingPlanetLabel = new Label("Starting planetary body:");
        grid.add(startingPlanetLabel, 0, 0);
        ComboBox<String> startingPlanetComboBox = new ComboBox<>();
        startingPlanetComboBox.getItems().addAll("Mercury", "Venus", "Earth", "Mars"); // Add your planet names here
        grid.add(startingPlanetComboBox, 1, 0);

        // Destination Planet
        Label destinationPlanetLabel = new Label("Destination planetary body:");
        grid.add(destinationPlanetLabel, 0, 1);
        ComboBox<String> destinationPlanetComboBox = new ComboBox<>();
        destinationPlanetComboBox.getItems().addAll("Mercury", "Venus", "Earth", "Mars"); // Add your planet names here
        grid.add(destinationPlanetComboBox, 1, 1);

        // Travel Vehicle
        Label vehicleLabel = new Label("Destination planetary body:");
        grid.add(destinationPlanetLabel, 0, 1);
        ComboBox<String> destinationPlanetComboBox2 = new ComboBox<>();
        destinationPlanetComboBox2.getItems().addAll("Mercury", "Venus", "Earth", "Mars"); // Add your planet names here
        grid.add(destinationPlanetComboBox2, 1, 1);

        // Travel Date
        Label travelDateLabel = new Label("Travel date (YYYY-MM-DD):");
        grid.add(travelDateLabel, 0, 2);
        DatePicker travelDatePicker = new DatePicker();
        grid.add(travelDatePicker, 1, 2);

        // Accuracy
        Label accuracyLabel = new Label("Accuracy:");
        grid.add(accuracyLabel, 0, 3);
        ComboBox<String> accuracyComboBox = new ComboBox<>();
        accuracyComboBox.getItems().addAll("Precise", "Estimate");
        grid.add(accuracyComboBox, 1, 3);

        Button calculateButton = new Button("Calculate");
        grid.add(calculateButton, 0, 4);
        Button stopButton = new Button("Stop");
        grid.add(stopButton, 1, 4);

        Scene scene = new Scene(grid, 400, 200);
        primaryStage.setScene(scene);
        primaryStage.show();

        calculateButton.setOnAction(event -> {
            // Retrieve selected values
            String startingPlanet = startingPlanetComboBox.getValue();
            String destinationPlanet = destinationPlanetComboBox.getValue();
            LocalDate travelDate = travelDatePicker.getValue();
            String accuracy = accuracyComboBox.getValue();

            // Perform calculations or further processing with the collected data
            // Example: System.out.println("Starting Planet: " + startingPlanet);
            // Example: System.out.println("Destination Planet: " + destinationPlanet);
            // Example: System.out.println("Travel Date: " + travelDate);
            // Example: System.out.println("Accuracy: " + accuracy);
        });

        stopButton.setOnAction(event -> {
            // Handle stopping action
        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}
