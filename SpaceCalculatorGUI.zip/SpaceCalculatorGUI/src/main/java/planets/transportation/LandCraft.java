/**
 * A class representing land vehicles in the transportation system.
 * Inherits from the TransportationVehicle class.
 */
package planets.transportation;

/**
 * Represents land vehicles in the transportation system.
 */
public class LandCraft extends TransportationVehicle {
    
    // Drag Coefficient for landcraft is given as 0.0744.
    private static final double DRAG_COEFICIENT = 0.0744;

    // Meals per day for landcrafts is 8.
    private static final double MEALS_PER_DAY = 5;

    // Pay hours per day for landcraft crew members is 16.
    private static final double PAY_HOURS_PER_DAY = 12;

    /**
     * Constructs a LandCraft object using data from an Excel row.
     *
     * @param excelDataRow Data from an Excel row to initialize the LandCraft.
     */
    public LandCraft(String[] excelDataRow) {
        super(excelDataRow);
        // TODO Auto-generated constructor stub
    }

    /**
     * Retrieves the daily salary per crew member for a LandCraft.
     *
     * @return The daily salary per crew member for a LandCraft.
     */
    @Override
    public double getDailySalaryPerCrewMember() {
        // TODO Auto-generated method stub
        return 0;
    }

    /**
     * Provides a string representation of the LandCraft object.
     *
     * @return A string representation of the LandCraft object.
     */
    @Override
    public String toString() {

    	return this.getVehicleName();
    }
    
    /**
     * Retrieves the drag coefficient for LandCraft.
     *
     * @return The drag coefficient for LandCraft.
     */
    public double getDragCoeficient() {
        return DRAG_COEFICIENT;
    }
    
    /**
     * Retrieves the number of meals per day for LandCraft crew members.
     *
     * @return The number of meals per day for LandCraft crew members.
     */
    public double getMealsPerDay() {
        return MEALS_PER_DAY;
    }
    
    /**
     * Retrieves the pay hours per day for LandCraft crew members.
     *
     * @return The pay hours per day for LandCraft crew members.
     */
    public double getPayHoursPerDay() {
        return PAY_HOURS_PER_DAY;
    }

	@Override
	public String getElementName() {
		// TODO Auto-generated method stub
		return this.getVehicleName();

	}

}
