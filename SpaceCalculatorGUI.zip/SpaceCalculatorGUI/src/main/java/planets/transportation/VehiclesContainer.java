package planets.transportation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import assignment.data.DataAccessElement;
import assignment.data.DataAccessOperations;

/**
 * Represents a container for transportation vehicles.
 */
public class VehiclesContainer implements DataAccessOperations {

    /** The list of transportation vehicles. */
    protected List<TransportationVehicle> vehicles;
    
    /** The list of names of the transportation vehicles. */
    protected List<String> listOfNames;
    
    TransportationVehicleFactory factory = new TransportationVehicleFactory();


    /**
     * Constructs a VehiclesContainer object using the provided list of vehicle data.
     * Also iterates through the list and creates an individual and appropriate Transportation vehicle, then stores that vehicle in an ArrayList
     * @param vehicleList A list containing details of the vehicles.
     */
    public VehiclesContainer(List<String[]> vehicleList) {

        this.vehicles = new ArrayList<TransportationVehicle>();
        this.listOfNames = new ArrayList<String>();

        // Iterate through each row of data within the vehicleList, and create the
        // appropriate transportation vehicle based on the classification, then add it to the
        // List<TransportationVehicle>.
        for (int i = 0; i < vehicleList.size(); i++) {
            this.listOfNames.add(vehicleList.get(i)[1]);

            // Use the factory to create the appropriate transportation vehicle
            TransportationVehicle newVehicle = factory.createTransportationVehicle(vehicleList.get(i));
            if (newVehicle != null) {
                this.vehicles.add(newVehicle);
            } else {
                // Handle the case when the classification is none of the above
                // TODO: DISPLAY ERROR
            }
        }
    }

    /**
     * Retrieves the list of names of the transportation vehicles.
     *
     * @return The list of names of the transportation vehicles.
     */
    @Override
    public List<String> getNameList() {
        return this.listOfNames;
    }
    
    /**
	 * Retrieves the list of Vehicle names sorted alphabetically.
	 *
	 * @return The list of names of the planetary bodies.
	 */
	public List<String> getSortedNameList() {
		
		/**
		 * java.util.Collections.sort() is used to sort the elements present in the specified list of Collection in ascending order. 
		 */
		Collections.sort(this.listOfNames); 
		
		/**
		 * Return the sorted list
		 */
		return this.listOfNames;
	}


    /**
     * Finds a transportation vehicle by name.
     *
     * @param name The name of the vehicle to find.
     * @return The transportation vehicle with the matching name, or null if not found.
     */
    @Override
    public DataAccessElement findElementByName(String name) {
        for (DataAccessElement element : this.vehicles) {
            if (element.getElementName().equals(name)) {
                return element; // Return the first element with the matching name
            }
        }
        return null;
    }
}
