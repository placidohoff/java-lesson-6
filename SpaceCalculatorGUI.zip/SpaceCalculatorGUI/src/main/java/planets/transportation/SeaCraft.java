/**
 * A class representing sea vessels in the transportation system.
 * Inherits from the TransportationVehicle class.
 */
package planets.transportation;

/**
 * Represents sea vessels in the transportation system.
 */
public class SeaCraft extends TransportationVehicle {

    // Drag Coefficient for sea vessels is given as 0.0744.
    private static final double DRAG_COEFICIENT = 0.0744;

    // Meals per day for sea vessels is 8.
    private static final double MEALS_PER_DAY = 8;

    // Pay hours per day for sea vessel crew members is 16.
    private static final double PAY_HOURS_PER_DAY = 16;

    /**
     * Constructs a SeaCraft object using data from an Excel row.
     *
     * @param excelDataRow Data from an Excel row to initialize the SeaCraft.
     */
    public SeaCraft(String[] excelDataRow) {
        super(excelDataRow);
    }

    /**
     * Retrieves the daily salary per crew member for a SeaCraft.
     *
     * @return The daily salary per crew member for a SeaCraft.
     */
    @Override
    public double getDailySalaryPerCrewMember() {
        // TODO Auto-generated method stub
        return 0;
    }

    /**
     * Provides a string representation of the SeaCraft object.
     *
     * @return A string representation of the SeaCraft object.
     */
    @Override
    public String toString() {
    	return this.getVehicleName();
    }

    /**
     * Retrieves the drag coefficient for SeaCraft.
     *
     * @return The drag coefficient for SeaCraft.
     */
    public double getDragCoeficient() {
        return DRAG_COEFICIENT;
    }

    /**
     * Retrieves the number of meals per day for SeaCraft crew members.
     *
     * @return The number of meals per day for SeaCraft crew members.
     */
    public static double mealsPerDay() {
        return MEALS_PER_DAY;
    }

    /**
     * Retrieves the pay hours per day for SeaCraft crew members.
     *
     * @return The pay hours per day for SeaCraft crew members.
     */
    public double getPayHoursPerDay() {
        return PAY_HOURS_PER_DAY;
    }

	@Override
	public String getElementName() {
		// TODO Auto-generated method stub
		return this.getVehicleName();

	}

	@Override
	public double getMealsPerDay() {
		// TODO Auto-generated method stub
		return MEALS_PER_DAY;
	}


}
