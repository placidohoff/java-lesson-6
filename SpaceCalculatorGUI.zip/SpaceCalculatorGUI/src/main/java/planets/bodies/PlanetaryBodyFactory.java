package planets.bodies;

public class PlanetaryBodyFactory {

    public PlanetaryBody createPlanetaryBody(String[] data) {
    	/** 
    	 * data[2] is the string of classification which determines the PlanetaryBody subclass to be instantiated
    	 * */
        switch (data[2]) {
            case "Planet":
                return new Planet(data);
            case "Moon":
                return new Moon(data);
            case "Dwarf planet":
                return new DwarfPlanet(data);
            default:
                // Handle the case when the celestial type is none of the above
                return null;
        }
    }
}