package planets.bodies;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import assignment.data.DataAccessElement;
import assignment.data.DataAccessOperations;

/**
 * Represents a container for planetary bodies in the solar system.
 */
public class PlanetaryBodiesContainer implements DataAccessOperations {

	private List<PlanetaryBody> planetaryBodies;
	private List<String> listOfNames;
	PlanetaryBodyFactory factory = new PlanetaryBodyFactory();
	private static final Logger logger = LogManager.getLogger(PlanetaryBodiesContainer.class);


	/**
	 * Constructs a PlanetaryBodiesContainer and populates it with planetary bodies through a PlanetaryBodies Factory class
	 * based on the provided list of data.
	 *
	 * @param planetsList The list of data containing information about planetary
	 *                    bodies.
	 */
	public PlanetaryBodiesContainer(List<String[]> planetsList) {
		this.planetaryBodies = new ArrayList<>();
		this.listOfNames = new ArrayList<>();

		 // Iterate through each row of data within the planetsList, and create the
        // appropriate PlanetaryBody such as Planet, Moon, etc, then add it to the
        // List<PlanetaryBody>.
        for (int i = 0; i < planetsList.size(); i++) {
            // Add the name to the list of names
            this.listOfNames.add(planetsList.get(i)[1]);

            // Use the factory to create the appropriate planetary body
            try {
                PlanetaryBody newBody = factory.createPlanetaryBody(planetsList.get(i));
                if (newBody != null) {
                    this.planetaryBodies.add(newBody);
                } else {
                    // Handle the case when the celestial type is none of the above
                    // TODO: DISPLAY ERROR
                    logger.error("Failed to create PlanetaryBody for data: {}", planetsList.get(i));
                }
            } catch (Exception e) {
                // Log the exception using Log4j
                logger.error("Error creating PlanetaryBody for data: {}", planetsList.get(i), e);
                
            }
        }
	}

	/**
	 * Retrieves the list of names of the planetary bodies.
	 *
	 * @return The list of names of the planetary bodies.
	 */
	@Override
	public List<String> getNameList() {
		return this.listOfNames;
	}
	
	
	/**
	 * Retrieves the list of Planetary Body names sorted alphabetically.
	 *
	 * @return The list of names of the planetary bodies.
	 */
	public List<String> getSortedNameList() {
		
		/**
		 * java.util.Collections.sort() is used to sort the elements present in the specified list of Collection in ascending order. 
		 */
		Collections.sort(this.listOfNames); 
		
		/**
		 * Return the sorted list
		 */
		return this.listOfNames;
	}


	/**
	 * Finds a planetary body element by its name.
	 *
	 * @param name The name of the planetary body to search for.
	 * @return The planetary body element with the specified name, or null if not
	 *         found.
	 */
	@Override
	public DataAccessElement findElementByName(String name) {
		for (DataAccessElement element : this.planetaryBodies) {
			if (element.getElementName().equals(name)) {
				return element; // Return the first element with the matching name
			}
		}
		return null;
	}
}