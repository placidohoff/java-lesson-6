package planets.bodies;

/**
 * Represents a moon orbiting a celestial body.
 */
public class Moon extends PlanetaryBody {

    /**
     * Constructs a moon object using the provided array of moon details.
     *
     * @param excelDataRow An array containing details of the moon.
     */
    public Moon(String[] excelDataRow) {
        super(excelDataRow);
    }

    /**
     * Retrieves the name of the moon.
     *
     * @return The name of the moon.
     */
    @Override
    public String getElementName() {
        return this.name;
    }

    /**
     * Returns a string representation of the moon.
     *
     * @return A string representation of the moon.
     */
    @Override
    public String toString() {
        return this.getElementName();
    }

    /**
     * Calculates and returns the drag coefficient of the moon.
     *
     * @return The drag coefficient of the moon.
     */
    @Override
    public double getDragCoeficient() {
        return 0.75 + (this.albedo * this.orbitalEccentricity);
    }

}
