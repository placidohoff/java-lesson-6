package planets.bodies;

/**
 * Represents a dwarf planet in the solar system.
 */
public class DwarfPlanet extends PlanetaryBody {

    /**
     * Constructs a dwarf planet object using the provided array of dwarf planet details.
     *
     * @param excelDataRow An array containing details of the dwarf planet.
     */
    public DwarfPlanet(String[] excelDataRow) {
        super(excelDataRow);
    }

    /**
     * Retrieves the name of the dwarf planet.
     *
     * @return The name of the dwarf planet.
     */
    @Override
    public String getElementName() {
        return this.name;
    }

    /**
     * Returns a string representation of the dwarf planet.
     *
     * @return A string representation of the dwarf planet.
     */
    @Override
    public String toString() {
        return this.getElementName();
    }

    /**
     * Calculates and returns the drag coefficient of the dwarf planet.
     *
     * @return The drag coefficient of the dwarf planet.
     */
    @Override
    public double getDragCoeficient() {
        return 0.35 + (this.albedo * this.orbitalEccentricity);
    }

}
