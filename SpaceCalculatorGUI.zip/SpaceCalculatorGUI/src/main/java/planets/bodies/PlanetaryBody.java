/**
 *
 */
package planets.bodies;

import assignment.data.DataAccessElement;

/**
 * Represents a planetary body in the solar system.
 */
public abstract class PlanetaryBody implements DataAccessElement {

    public String name;
    public String classification;
    public String orbits;
    public double diameterKm;
    public double dayLengthHours;
    public double yearLengthDays;
    public int numberOfMoons;
    public double gravity;
    public double lowestTemperature;
    public double highestTemperature;
    public double averageTemperature;
    public boolean hasRings;
    public String atmosphericComposition;
    public String knownFor;
    public String surfacePressureAtm;
    public String type;
    public double orbitalEccentricity;
    public double albedo;
    public double weightRelativeToEarth;
    public double avgDistanceFromEarthKm;
    public double avgDistanceFromSunKm;
    public double closestDistanceFromEarthKm;
    public double closestDistanceFromSunKm;
    public double furthestDistanceFromEarthKm;
    public double furthestDistanceFromSunKm;
    public String description;
    public String interestingFact;
    public String notes;

    /**
     * Constructor for a planetary body.
     *
     * @param excelDataRow An array containing data about the planetary body.
     */
    public PlanetaryBody(String[] excelDataRow) {
        this.name = excelDataRow[1];
        this.classification = excelDataRow[2];
        this.orbits = excelDataRow[3];
        this.diameterKm = Double.parseDouble(excelDataRow[4]);
        this.dayLengthHours = Double.parseDouble(excelDataRow[5]);
        this.yearLengthDays = Double.parseDouble(excelDataRow[6]);
        this.numberOfMoons = Integer.parseInt(excelDataRow[7]);
        this.gravity = Double.parseDouble(excelDataRow[8]);
        this.lowestTemperature = Double.parseDouble(excelDataRow[9]);
        this.highestTemperature = Double.parseDouble(excelDataRow[10]);
        this.averageTemperature = Double.parseDouble(excelDataRow[11]);
        this.hasRings = Boolean.parseBoolean(excelDataRow[12]);
        this.atmosphericComposition = excelDataRow[13];
        this.knownFor = excelDataRow[14];
        this.surfacePressureAtm = excelDataRow[15];
        this.type = excelDataRow[16];
        this.orbitalEccentricity = Double.parseDouble(excelDataRow[17]);
        this.albedo = Double.parseDouble(excelDataRow[18]);
        this.weightRelativeToEarth = Double.parseDouble(excelDataRow[19]);
        this.avgDistanceFromEarthKm = Double.parseDouble(excelDataRow[20]);
        this.avgDistanceFromSunKm = Double.parseDouble(excelDataRow[21]);
        this.closestDistanceFromEarthKm = Double.parseDouble(excelDataRow[22]);
        this.closestDistanceFromSunKm = Double.parseDouble(excelDataRow[23]);
        this.furthestDistanceFromEarthKm = Double.parseDouble(excelDataRow[24]);
        this.furthestDistanceFromSunKm = Double.parseDouble(excelDataRow[25]);
        this.description = excelDataRow[26];
        this.interestingFact = excelDataRow[27];
        this.notes = excelDataRow[28];
    }

    /**
     * Retrieves the name of the planetary body.
     *
     * @return The name of the planetary body.
     */
    @Override
    public abstract String getElementName();

    /**
     * Retrieves a string representation of the planetary body.
     *
     * @return A string representation of the planetary body.
     */
    @Override
    public abstract String toString();

    /**
     * Retrieves the drag coefficient of the planetary body.
     *
     * @return The drag coefficient.
     */
    public abstract double getDragCoeficient();

    /**
     * Retrieves the number of days per year for the planetary body.
     *
     * @return The number of days per year.
     */
    public double getDaysPerYear() {
        return this.yearLengthDays;
    }

    /**
     * Retrieves the average distance from the Sun for the planetary body.
     *
     * @return The average distance from the Sun in kilometers.
     */
    public double getAvgDistanceFromTheSun() {
        return this.avgDistanceFromSunKm;
    }


}
