/**
 * Singleton class used for loading the values of the constants that will be used for calculation.
 * The values of the constants will depend on the user's one-time selection.
 */
package planets.util;

import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import assignment.poi.PoiUtility;

/**
 * Singleton class used for loading the values of the constants that will be used for calculation.
 * The values of the constants will depend on the user's one-time selection.
 */
public class PlanetaryConstants {
	
	// Flag to indicate the level of accuracy for constants
	private static boolean _isAccuracy;
	
	// Singleton instance of PlanetaryConstants
	private static PlanetaryConstants planetaryConstants;
	
	// List to hold data from XML
	private static List<String[]> listDataFromXML;
	
	// File path for constants XML file
	private final static String FILE_PATH = AppConfig.getConstantsFilePath();
	
	// Constants loaded from XML
	private final String ACCURACY_TYPE;
	private final double HOURS_IN_DAY;
	private final double DAYS_IN_YEAR;
	private final double GRAVITATIONAL_CONSTANT;
	private final double MASS_OF_SUN;
	private final double POUNDS_TO_KILOGRAMS;
	private final double KILOGRAMS_TO_POUNDS;
	private final double MILES_TO_KILOMETERS;
	private final double KILOMETERS_TO_MILES;
	
	
	/**
	 * Constructor for PlanetaryConstants.
	 * @param dataFromXML Array containing constant values loaded from XML
	 */
	private PlanetaryConstants(String[] dataFromXML) {
		ACCURACY_TYPE = dataFromXML[0];
		HOURS_IN_DAY = Double.parseDouble(dataFromXML[1]);
		DAYS_IN_YEAR = Double.parseDouble(dataFromXML[2]);
		GRAVITATIONAL_CONSTANT = Double.parseDouble(dataFromXML[3]);
		MASS_OF_SUN = Double.parseDouble(dataFromXML[4]);
		POUNDS_TO_KILOGRAMS = Double.parseDouble(dataFromXML[5]);
		KILOGRAMS_TO_POUNDS = Double.parseDouble(dataFromXML[6]);
		MILES_TO_KILOMETERS = Double.parseDouble(dataFromXML[7]);
		KILOMETERS_TO_MILES = Double.parseDouble(dataFromXML[8]);
	}
	
	/**
	 * Get the singleton instance of PlanetaryConstants.
	 * @return Singleton instance of PlanetaryConstants
	 */
	public static PlanetaryConstants getInstance() {
		return planetaryConstants;
	}
	
	/**
	 * Create an instance of PlanetaryConstants based on the provided accuracy level.
	 * @param isAccurate Flag indicating whether to use accurate constants
	 * @throws ParserConfigurationException If an error occurs during XML parsing configuration
	 */
	public static void CreateInstance(boolean isAccurate) throws ParserConfigurationException {
		// Path must come from AppConfig
		listDataFromXML = PoiUtility.getConstantsDataFromXML(FILE_PATH);
		
		// Choose data based on accuracy level
		if(isAccurate) {
			planetaryConstants = new PlanetaryConstants(listDataFromXML.get(0));
		} else {
			planetaryConstants = new PlanetaryConstants(listDataFromXML.get(1));
		}
	}
	
	// Static getters for constants
	
	public static String getAccuracyType() {
		return planetaryConstants.ACCURACY_TYPE;
	}

	public static double getHoursInDay() {
		return planetaryConstants.HOURS_IN_DAY;
	}

	public static double getDaysInYear() {
		return planetaryConstants.DAYS_IN_YEAR;
	}

	public static double getGravitationalConstant() {
		return planetaryConstants.GRAVITATIONAL_CONSTANT;
	}

	public static double getMassOfSun() {
		return planetaryConstants.MASS_OF_SUN;
	}

	public static double getPoundsToKilograms() {
		return planetaryConstants.POUNDS_TO_KILOGRAMS;
	}

	public static double getKilogramsToPounds() {
		return planetaryConstants.KILOGRAMS_TO_POUNDS;
	}

	public static double getMilesToKilometers() {
		return planetaryConstants.MILES_TO_KILOMETERS;
	}

	public static double getKilometersToMiles() {
		return planetaryConstants.KILOMETERS_TO_MILES;
	}
}
