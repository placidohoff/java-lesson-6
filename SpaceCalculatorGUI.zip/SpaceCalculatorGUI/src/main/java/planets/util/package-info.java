/**
 * Static utility classes used throughout the application.
 * 
 */
package planets.util;
