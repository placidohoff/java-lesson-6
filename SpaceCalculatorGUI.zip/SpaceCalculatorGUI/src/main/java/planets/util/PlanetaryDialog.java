/**
 * Planetary dialogs for all user input.
 */
package planets.util;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.WindowConstants;

// import edu.ccri.lesson03.planets.data.PlanetaryConstantData;

/**
 * Planetary dialogs for all user input and user output. <BR>
 * <BR>
 * <B>Input Dialog</B><BR>
 * The input dialog has the potential to present multiple input fields.<BR>
 * In order to show (use) an input field the corresponding <code>useX()</code>
 * (e.g. <code>useStartingPlanet()</code> method must be called prior to
 * the invocation of <code>showMultiEditDialog()</code>.<BR>
 * If a field contains a value (e.g. the starting planet is set to "earth") then
 * the field is displayed and read-only. Read-only fields are green.<BR>
 * If the "Calculate" button is selected and the fields fail to validate, a
 * message will be displaed and the text field will be red.<BR>
 * Only 'used' fields are validated and set in the object when validation is
 * successful.<BR>
 * Selecting the "Stop" button will stop processing.<BR>
 *
 * <BR>
 * <B>Output Dialog</B><BR>
 * The ouput dialog is a simple display of a string. The only formatting
 * required in the string is the new line (\n) character.<BR>
 * Use the "X" in the top right corner of the window to close the dialog.
 *
 * @author dean grammas
 * @version 2023-12-07
 */
public class PlanetaryDialog {
    /**
     * Calculate button
     */
    private static final String BUTTON_CALCULATE = "Calculate";

    /**
     * Stop button
     */
    private static final String BUTTON_STOP = "Stop";

    /**
     * Color black
     */
    private static final Color COLOR_BLACK = new Color(0, 0, 0);

    /**
     * Color red
     */
    private static final Color COLOR_BLUE = new Color(0, 0, 255);

    /**
     * Color black
     */
    private static final Color COLOR_GREEN = new Color(60, 179, 113);

    /**
     * Color red
     */
    private static final Color COLOR_RED = new Color(255, 0, 0);

    /**
     * Combo options for accuracy
     */
    // private static final String[] COMBO_ACCURACY =
    // { PlanetaryConstantData.NAME_VALUE_PRECISE,
    // PlanetaryConstantData.NAME_VALUE_ESTIMATE };

    private static final String[] COMBO_ACCURACY =
            { "Precise",
                    "Estimate" };

    /**
     * Accuracy?
     */
    private static final String DIALOG_ACCURACY = "Accuracy?";

    /**
     * Button options
     */
    private static final String[] DIALOG_BUTTON_OPTIONS = { PlanetaryDialog.BUTTON_CALCULATE,
            PlanetaryDialog.BUTTON_STOP };

    /**
     * Conversion rate?
     */
    private static final String DIALOG_CONVERSION_RATE = "What is the dollar to euro conversion rate?";

    /**
     * Converstion rate text
     */
    private static final String DIALOG_CONVERSION_RATES_LINK = "https://www.x-rates.com/table/?from=USD&amount=1";

    /**
     * Date format
     */
    private static final String DIALOG_DATE_FORMAT = "yyyy-MM-dd";

    /**
     * Destination planet name?
     */
    private static final String DIALOG_DESTINATION_PLANET_NAME = "Destination planetary body?";

    /**
     * Dialog error conversion rate required
     */
    private static final String DIALOG_ERROR_CONVERSION_RATE_REQURED = "Conversion rate is required! ";

    /**
     * Dialog error date invalid
     */
    private static final String DIALOG_ERROR_DATE_INVALID = "Date format invalid! ";

    /**
     * Dialog error date required
     */
    private static final String DIALOG_ERROR_DATE_REQURED = "Date is required! ";

    /**
     * Dialog grid cols
     */
    private static final int DIALOG_GRID_COLUMNS = 1;

    /**
     * Dialog grid rows
     */
    private static final int DIALOG_GRID_ROWS = 2;

    /**
     * Title
     */
    private static final String DIALOG_HEADER = "Planetary Calculator";

    /**
     * Title results
     */
    private static final String DIALOG_HEADER_RESULTS = "Planetary Calculator Results";

    /**
     * Url link prefix
     */
    private static final String DIALOG_LINK_URL_PREFIX = "<html><a href='";

    /**
     * Url link prefix close
     */
    private static final String DIALOG_LINK_URL_PREFIX_CLOSE = "'>";

    /**
     * Url link suffix
     */
    private static final String DIALOG_LINK_URL_SUFFIX = "</a></html>";

    /**
     * Informational message
     */
    private static final String DIALOG_MESSAGE_INFO = "Enter the details to calculate the results.";

    /**
     * Starting planetary body?
     */
    private static final String DIALOG_STARTING_PLANET_NAME = "Starting planetary body?";

    /**
     * Transporation vehicle?
     */
    private static final String DIALOG_TRANSPORTATION_VEHICLE = "Transporation vehicle?";

    /**
     * Travel date
     */
    private static final String DIALOG_TRAVEL_DATE = "Travel date (YYYY-MM-DD)?";

    /**
     * Accuracy of calculations
     */
    private String accuracy;

    /**
     * Destination planet message
     */
    private String destinationPlanetName;

    /**
     * Dollar to Euro conversion rate
     */
    private double dollarToEuroConversionRate = -1.0;

    /**
     * Message of the dialog
     */
    private String message;

    /**
     * Starting planet message
     */
    private String startingPlanetName;

    /**
     * True to stop, false to continue
     */
    private boolean stop = false;

    /**
     * Transportation vehicle message
     */
    private String transportationVechicleName;

    /**
     * Travel date
     */
    private Date travelDate;

    /**
     * True to use accuracy
     */

    private boolean useAccuracy;

    /**
     * True to use conversion rate
     */

    private boolean useConversionRate;

    /**
     * True to use destination planet
     */
    private boolean useDestinationPlanet;

    /**
     * True to use source planet
     */
    private boolean useStartingPlanet;

    /**
     * True to use transportation vehicle
     */
    private boolean useTransporationVehicle;

    /**
     * True to use travel date
     */
    private boolean useTravelDate;

    /**
     * Constructor
     *
     * @param message - message of the dialog
     */
    public PlanetaryDialog(String message) {
        super();
        this.setMessage(message);
    }

    /**
     * Add combo field to panel.
     *
     * @param useField         - true to use field
     * @param preSelectedValue - null or pre-selected value
     * @param jPanel           - panel
     * @param elementList      - element list
     * @param lable            - lable
     * @return field which was added to the panel
     */
    private JComboBox<Object> addFieldCombo(boolean useField, String preSelectedValue, JPanel jPanel,
                                            Object[] elementList, String lable) {
        JComboBox<Object> component = null;

        if (useField) {
            this.adjustGridLayoutRows(jPanel, 2);

            if (null != preSelectedValue) {
                component = this.addFieldCombo(jPanel, preSelectedValue, lable, PlanetaryDialog.COLOR_GREEN, false);
            } else {
                component = this.addFieldCombo(jPanel, elementList, lable, PlanetaryDialog.COLOR_BLACK, true);
            }
        }
        return component;
    }

    /**
     * Add combo field to panel.
     *
     * @param jPanel      - panel
     * @param elementList - element list
     * @param lable       - lable
     * @param color       - color
     * @param editable    - true if editble
     * @return field which was added to the panel
     */
    private JComboBox<Object> addFieldCombo(JPanel jPanel, Object[] elementList, String lable, Color color,
                                            boolean editable) {
        JComboBox<Object> component = new JComboBox<>(elementList);
        component.setEditable(editable);
        component.setForeground(color);

        jPanel.add(new JLabel(lable));
        jPanel.add(component);
        return component;
    }

    /**
     * Add combo field to panel.
     *
     * @param jPanel      - panel
     * @param elementItem - element item
     * @param lable       - lable
     * @param color       - color
     * @param editable    - true if editble
     * @return field which was added to the panel
     */
    private JComboBox<Object> addFieldCombo(JPanel jPanel, String elementItem, String lable, Color color,
                                            boolean editable) {
        String[] elementList = new String[] { elementItem };
        return this.addFieldCombo(jPanel, elementList, lable, color, editable);
    }

    /**
     * Add edit field to panel.
     *
     * @param jPanel      - panel
     * @param elementItem - element item
     * @param lable       - lable
     * @param color       - color
     * @param editable    - true if editble
     * @return field which was added to the panel
     */
    private JTextField addFieldEdit(JPanel jPanel, String elementItem, String lable, Color color, boolean editable) {
        JTextField component = new JTextField(elementItem);
        component.setEditable(editable);
        component.setForeground(color);

        jPanel.add(new JLabel(lable));
        jPanel.add(component);
        return component;
    }

    /**
     * Add date edit field to panel.
     *
     * @param useField         - true to use field
     * @param preSelectedValue - null or pre-selected value
     * @param jPanel           - panel
     * @param lable            - lable
     * @return field which was added to the panel
     */
    private JTextField addFieldEditDate(boolean useField, Date preSelectedValue, JPanel jPanel, String lable) {
        JTextField component = null;

        LocalDate dateObj = null;
        DateTimeFormatter formatter = null;
        String today = null;

        if (useField) {
            this.adjustGridLayoutRows(jPanel, 2);
            formatter = DateTimeFormatter.ofPattern(PlanetaryDialog.DIALOG_DATE_FORMAT);

            if (null != preSelectedValue) {
                dateObj = preSelectedValue.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                component = this.addFieldEdit(jPanel, String.valueOf(dateObj.format(formatter)), lable,
                        PlanetaryDialog.COLOR_GREEN, false);
            } else {
                dateObj = LocalDate.now();
                today = dateObj.format(formatter);
                component = this.addFieldEdit(jPanel, today, lable, PlanetaryDialog.COLOR_BLACK, true);
            }
        }
        return component;
    }

    /**
     * Add text edit field to panel.
     *
     * @param useField         - true to use field
     * @param preSelectedValue - null or pre-selected value
     * @param jPanel           - panel
     * @param lable            - lable
     * @param link             - link
     * @return field which was added to the panel
     */
    private JTextField addFieldEditText(boolean useField, Double preSelectedValue, JPanel jPanel, String lable,
                                        String link) {
        JTextField component = null;

        if (useField) {
            this.adjustGridLayoutRows(jPanel, 3);
            if (preSelectedValue >= 0.0) {
                component = this.addFieldEditText(jPanel, String.valueOf(preSelectedValue), lable, link,
                        PlanetaryDialog.COLOR_GREEN, false);
            } else {
                component = this.addFieldEditText(jPanel, "", lable, link, PlanetaryDialog.COLOR_BLACK, true);
            }
        }
        return component;
    }

    /**
     * Add edit field to panel.
     *
     * @param jPanel      - panel
     * @param elementItem - element item
     * @param lable       - lable
     * @param link        - link
     * @param color       - color
     * @param editable    - true if editble
     * @return field which was added to the panel
     */
    private JTextField addFieldEditText(JPanel jPanel, String elementItem, String lable, String link, Color color,
                                        boolean editable) {
        JTextField component = this.addFieldEdit(jPanel, elementItem, lable, color, editable);
        component.setEditable(editable);
        component.setForeground(color);
        this.addHtmlLink(jPanel, link);
        return component;
    }

    /**
     * Add html link
     *
     * @param jPanel - panel
     * @param link   - link to website to navigate to
     */
    private void addHtmlLink(JPanel jPanel, String link) {
        JLabel label = null;
        StringBuilder sb = null;
        if (null != link) {
            sb = new StringBuilder();
            sb.append(PlanetaryDialog.DIALOG_LINK_URL_PREFIX);
            sb.append(link);
            sb.append(PlanetaryDialog.DIALOG_LINK_URL_PREFIX_CLOSE);
            sb.append(link);
            sb.append(PlanetaryDialog.DIALOG_LINK_URL_SUFFIX);

            label = new JLabel(sb.toString());
            jPanel.add(label);

            label.setCursor(new Cursor(Cursor.HAND_CURSOR));
            this.navigateToWebsite(label, link);
        }
    }

    /**
     * Adjust the number of rows in the grid layout
     *
     * @param jPanel  - panel
     * @param numRows - number of rows to increase (or decrease)
     */
    private void adjustGridLayoutRows(JPanel jPanel, int numRows) {
        GridLayout gl = (GridLayout) jPanel.getLayout();
        gl.setRows(gl.getRows() + numRows);
    }

    /**
     * Assign accuracy
     *
     * @param element accuracy
     */
    private void assignAccuracy(JComboBox<Object> element) {
        if (this.useAccuracy()) {
            this.setAccuracy((String) element.getSelectedItem());
        }
    }

    /**
     * Assign conversion rate
     *
     * @param conversionRate conversion rate
     */
    private void assignConversionRate(Double conversionRate) {
        if (this.useConversionRate()) {
            this.setDollarToEuroConversionRate(conversionRate);
        }
    }

    /**
     * Assign destination planet
     *
     * @param element destination planet
     */
    private void assignDestinationPlanet(JComboBox<Object> element) {

        if (this.useDestinationPlanet()) {
            this.setDestinationPlanetName((String) element.getSelectedItem());
        }
    }

    /**
     * Assign starting planet
     *
     * @param element starting planet
     */
    private void assignStartingPlanet(JComboBox<Object> element) {
        if (this.useStartingPlanet()) {
            this.setStartingPlanetName((String) element.getSelectedItem());
        }
    }

    /**
     * Assign transporation vehicle
     *
     * @param element transporation vehicle
     */
    private void assignTransporationVehicle(JComboBox<Object> element) {

        if (this.useTransporationVehicle()) {
            this.setTransportationVehicleName((String) element.getSelectedItem());
        }
    }

    /**
     * Assign travel date
     *
     * @param startDate travel date
     */
    private void assignTravelDate(Date startDate) {
        if (this.useTravelDate()) {
            this.setTravelDate(startDate);
        }
    }

    /**
     * Get accuracy
     *
     * @return the accuracy
     */
    public String getAccuracy() {
        return this.accuracy;
    }

    /**
     * Get destinationPlanetName
     *
     * @return the destinationPlanetName
     */
    public String getDestinationPlanetName() {
        return this.destinationPlanetName;
    }

    /**
     * Get dollarToEuroConversionRate
     *
     * @return the dollarToEuroConversionRate
     */
    public double getDollarToEuroConversionRate() {
        return this.dollarToEuroConversionRate;
    }

    /**
     * Get message
     *
     * @return the message
     */
    private String getMessage() {
        return this.message;
    }

    /**
     * Get starting planet message
     *
     * @return the startingPlanetName
     */
    public String getStartingPlanetName() {
        return this.startingPlanetName;
    }

    /**
     * Get transportationVechicleName
     *
     * @return the transportationVechicleName
     */
    public String getTransportationVechicleName() {
        return this.transportationVechicleName;
    }

    /**
     * Get travel date
     *
     * @return the travelDate
     */
    public Date getTravelDate() {
        return this.travelDate;
    }

    /**
     * True if stop
     *
     * @return the stop
     */
    public boolean isStop() {
        return this.stop;
    }

    /**
     * Navigate to the website
     *
     * @param component - component label
     * @param link      to website to navigate to
     */
    private void navigateToWebsite(JLabel component, String link) {
        component.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    Desktop.getDesktop().browse(new URI(link));
                } catch (URISyntaxException | IOException ex) {
                    // It looks like there's a problem
                }
            }
        });
    }

    /**
     * Set accuracy
     *
     * @param accuracy the accuracy to set
     */
    public void setAccuracy(String accuracy) {
        this.accuracy = accuracy;
    }

    /**
     * Set destinationPlanet
     *
     * @param destinationPlanet the destinationPlanet to set
     */
    public void setDestinationPlanetName(String destinationPlanet) {
        this.destinationPlanetName = destinationPlanet;
    }

    /**
     * Set dollarToEuroConversionRate
     *
     * @param dollarToEuroConversionRate the dollarToEuroConversionRate to set
     */
    public void setDollarToEuroConversionRate(double dollarToEuroConversionRate) {
        this.dollarToEuroConversionRate = dollarToEuroConversionRate;
    }

    /**
     * Set message
     *
     * @param message the message to set
     */
    private void setMessage(String message) {
        this.message = message;
    }

    /**
     * Set starting planet message
     *
     * @param startingPlanetName the startingPlanetName to set
     */
    public void setStartingPlanetName(String startingPlanetName) {
        this.startingPlanetName = startingPlanetName;
    }

    /**
     * Set true to stop
     *
     * @param stop the stop to set
     */
    private void setStop(boolean stop) {
        this.stop = stop;
    }

    /**
     * Set Transportation Vehicle Name
     *
     * @param transportationVechicleName the transportationVechicleName to set
     */
    public void setTransportationVehicleName(String transportationVechicleName) {
        this.transportationVechicleName = transportationVechicleName;
    }

    /**
     * Set travel date
     *
     * @param travelDate the travelDate to set
     */
    public void setTravelDate(Date travelDate) {
        this.travelDate = travelDate;
    }

    /**
     * True to use accuracy
     */
    public void setUseAccuracy() {
        this.useAccuracy = true;
    }

    /**
     * True to use conversion rate
     */
    public void setUseConversionRate() {
        this.useConversionRate = true;
    }

    /**
     * True to use destination planet
     */
    public void setUseDestinationPlanet() {
        this.useDestinationPlanet = true;
    }

    /**
     * True to use starting planet
     */
    public void setUseStartingPlanet() {
        this.useStartingPlanet = true;
    }

    /**
     * True to use transportation vehicle
     */
    public void setUseTransporationVehicle() {
        this.useTransporationVehicle = true;
    }

    /**
     * True to use travel date
     */
    public void setUseTravelDate() {
        this.useTravelDate = true;
    }

    /**
     * Displays the results in a modal dialog.
     *
     * @param results - results to display
     */
    public void showModalDialog(String results) {
        // Creating the modal dialog.
        JDialog dialog = new JDialog();
        dialog.setTitle(PlanetaryDialog.DIALOG_HEADER_RESULTS);
        dialog.setModal(true); // Setting the dialog as modal.
        dialog.setSize(500, 750);
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        // Creating the text area.
        JTextArea textArea = new JTextArea();
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);

        textArea.setText(results);

        // Adding scroll pane to text area.
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

        // Adding the scroll pane to the dialog.
        dialog.getContentPane().add(scrollPane, BorderLayout.CENTER);

        // Centering the dialog on the screen.
        dialog.setLocationRelativeTo(null);

        // Displaying the dialog.
        dialog.setVisible(true);
    }

    /**
     * Use mult-edit dialog to get details
     *
     * @param planetNameList           - list of planet names
     * @param transportVehicleNameList = list of transport vehicle names
     */
    public void showMultiEditDialog(Object[] planetNameList, Object[] transportVehicleNameList) {
        int button = 0;
        StringBuilder errorMessage = new StringBuilder();

        Date startDate = null;
        double conversionRate = -1;

        // create a display grid that is initially 2 rows and 1 column
        JPanel jPanel = new JPanel(
                new GridLayout(PlanetaryDialog.DIALOG_GRID_ROWS, PlanetaryDialog.DIALOG_GRID_COLUMNS));

        JLabel messageLabel = new JLabel(this.getMessage());

        // create the input fields, all width of 5 columns
        JComboBox<Object> jtfSourcePlanetName = null;
        JComboBox<Object> jtfDestinationPlanetName = null;
        JComboBox<Object> jtfTransportationVehicleName = null;
        JComboBox<Object> jtfAccuracy = null;

        JTextField jtfTravelDate = null;
        JTextField jtfConversionRate = null;

        // add the messages to the panel grid
        messageLabel.setForeground(PlanetaryDialog.COLOR_BLUE);
        jPanel.add(messageLabel);
        jPanel.add(new JLabel(PlanetaryDialog.DIALOG_MESSAGE_INFO));

        // add the combo boxes to the panel grid
        jtfSourcePlanetName = this.addFieldCombo(this.useStartingPlanet(), this.getStartingPlanetName(), jPanel,
                planetNameList, PlanetaryDialog.DIALOG_STARTING_PLANET_NAME);
        jtfDestinationPlanetName = this.addFieldCombo(this.useDestinationPlanet(), this.getDestinationPlanetName(),
                jPanel, planetNameList, PlanetaryDialog.DIALOG_DESTINATION_PLANET_NAME);
        jtfTransportationVehicleName = this.addFieldCombo(this.useTransporationVehicle(),
                this.getTransportationVechicleName(), jPanel, transportVehicleNameList,
                PlanetaryDialog.DIALOG_TRANSPORTATION_VEHICLE);
        jtfAccuracy = this.addFieldCombo(this.useAccuracy(), this.getAccuracy(),
                jPanel, PlanetaryDialog.COMBO_ACCURACY,
                PlanetaryDialog.DIALOG_ACCURACY);

        // add the text edit fields to the panel grid
        jtfTravelDate = this.addFieldEditDate(this.useTravelDate(), this.getTravelDate(), jPanel,
                PlanetaryDialog.DIALOG_TRAVEL_DATE);
        jtfConversionRate = this.addFieldEditText(this.useConversionRate(), this.getDollarToEuroConversionRate(),
                jPanel, PlanetaryDialog.DIALOG_CONVERSION_RATE, PlanetaryDialog.DIALOG_CONVERSION_RATES_LINK);

        // loop until they select stop or calculate (and all fields are valid)
        while (true) {
            button = JOptionPane.showOptionDialog(null, jPanel, PlanetaryDialog.DIALOG_HEADER, JOptionPane.NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE, null, PlanetaryDialog.DIALOG_BUTTON_OPTIONS, null);

            // if stop if the set cancel
            if (button == 1) {
                this.setStop(true);
                break;
            }

            // do some validation of the dialog data
            errorMessage.setLength(0);
            startDate = this.validateTravelDate(jtfTravelDate, errorMessage);
            conversionRate = this.validateConversionRate(jtfConversionRate, errorMessage);

            // houston, is there a problem?
            if (errorMessage.length() > 0) {
                messageLabel.setForeground(PlanetaryDialog.COLOR_RED);
                messageLabel.setText(errorMessage.toString());
            } else {
                // assign the values that we are using
                this.assignStartingPlanet(jtfSourcePlanetName);
                this.assignDestinationPlanet(jtfDestinationPlanetName);
                this.assignTransporationVehicle(jtfTransportationVehicleName);
                this.assignAccuracy(jtfAccuracy);
                this.assignTravelDate(startDate);
                this.assignConversionRate(conversionRate);

                // we are good to go home :-)!
                break;
            }
        }
    }

    /**
     * String representation
     *
     * @return String representation
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("PlanetaryDialog[");
        builder.append("this.getMessage()=");
        builder.append(this.getMessage());
        builder.append(", this.getStartingPlanetName()=");
        builder.append(this.getStartingPlanetName());
        builder.append(", this.getDestinationPlanetName()=");
        builder.append(this.getDestinationPlanetName());
        builder.append(", this.getTransportationVechicleName()=");
        builder.append(this.getTransportationVechicleName());
        builder.append(", this.getDollarToEuroConversionRate()=");
        builder.append(this.getDollarToEuroConversionRate());
        builder.append(", this.isStop()=");
        builder.append(this.isStop());
        builder.append("]");
        return builder.toString();
    }

    /**
     * True to use accuracy
     *
     * @return the useAccuracy
     */
    public boolean useAccuracy() {
        return this.useAccuracy;
    }

    /**
     * True to use conversion rate
     *
     * @return the useConversionRate
     */
    public boolean useConversionRate() {
        return this.useConversionRate;
    }

    /**
     * True to use destination planet
     *
     * @return the useDestinationPlanet
     */
    public boolean useDestinationPlanet() {
        return this.useDestinationPlanet;
    }

    /**
     * True to use starting planet
     *
     * @return the useStartingPlanet
     */
    public boolean useStartingPlanet() {
        return this.useStartingPlanet;
    }

    /**
     * True to use transportation vehicle
     *
     * @return the useTransporationVehicle
     */
    public boolean useTransporationVehicle() {
        return this.useTransporationVehicle;
    }

    /**
     * True to use travel date
     *
     * @return the useTravelDate
     */
    public boolean useTravelDate() {
        return this.useTravelDate;
    }

    /**
     * Validate conversion rate
     *
     * @param jtfConversionRate - conversion rate
     * @param errorMessage      - error message
     * @return conversion rate
     */
    private double validateConversionRate(JTextField jtfConversionRate, StringBuilder errorMessage) {
        double conversion = -1.0;
        if (this.useConversionRate) {
            jtfConversionRate.setForeground(PlanetaryDialog.COLOR_BLACK);
            conversion = this.verifyDouble(jtfConversionRate.getText().trim());
            if (conversion < 0) {
                errorMessage.append(PlanetaryDialog.DIALOG_ERROR_CONVERSION_RATE_REQURED);
                jtfConversionRate.setForeground(PlanetaryDialog.COLOR_RED);
            }
        }
        return conversion;
    }

    /**
     * Validate travel date
     *
     * @param jtfTravelDate - travel date
     * @param errorMessage  - error message
     * @return travel date
     */
    private Date validateTravelDate(JTextField jtfTravelDate, StringBuilder errorMessage) {
        Date startDate = null;
        if (this.useTravelDate()) {
            jtfTravelDate.setForeground(PlanetaryDialog.COLOR_BLACK);
            if (jtfTravelDate.getText().trim().length() == 0) {
                errorMessage.append(PlanetaryDialog.DIALOG_ERROR_DATE_REQURED);
                jtfTravelDate.setForeground(PlanetaryDialog.COLOR_RED);
            }

            startDate = this.verifyDate(jtfTravelDate.getText().trim());
            if (startDate == null) {
                errorMessage.append(PlanetaryDialog.DIALOG_ERROR_DATE_INVALID);
                jtfTravelDate.setForeground(PlanetaryDialog.COLOR_RED);
            }
        }
        return startDate;
    }

    /**
     * Verify date
     *
     * @param input - date string
     * @return date or null if date is invalid
     */
    private Date verifyDate(String input) {
        SimpleDateFormat sdf = new SimpleDateFormat(PlanetaryDialog.DIALOG_DATE_FORMAT);
        if (input != null) {
            try {
                java.util.Date ret = sdf.parse(input.trim());
                if (sdf.format(ret).equals(input.trim())) {
                    return ret;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    /**
     * Verify number
     *
     * @param input - number string
     * @return double or -1 if double is invalid
     */
    private double verifyDouble(String input) {
        double ret = -1;
        if (input != null) {
            try {
                ret = Double.parseDouble(input);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return ret;
    }
} // end class
