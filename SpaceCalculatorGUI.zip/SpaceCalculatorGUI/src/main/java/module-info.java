module com.spacetravel.spacecalculatorgui {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.xml;
    requires org.apache.poi.poi;
    requires org.apache.poi.ooxml;
    requires org.apache.commons.lang3;
    requires org.apache.logging.log4j;
    requires java.desktop;


    opens planets.main to javafx.fxml;
    exports planets.main;
}