package assignment.poi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.Document;

import assignment.data.FileDataSource;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;


import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
/**
 * Utility class for working with Excel files using Apache POI.
 */
public class PoiUtility implements FileDataSource {

    /**
     * Logger for logging events related to PoiUtility class.
     */
    public static final org.apache.logging.log4j.Logger logger = LogManager.getLogger(PoiUtility.class);

    /**
     * Retrieves data from an Excel file.
     *
     * @param path     The path to the Excel file.
     * @param sheetNum The index of the sheet to read data from.
     * @return A list containing String arrays representing the data from the Excel file.
     */
    @SuppressWarnings("deprecation")
    public static List<String[]> getData(String path, int sheetNum) {
        List<String[]> data = new ArrayList<>();

        try {
            // Load Excel file
            FileInputStream file = new FileInputStream(new File(path));
            Workbook workbook = WorkbookFactory.create(file);

            // Get the specified sheet
            Sheet sheet1 = workbook.getSheetAt(sheetNum);

            // Iterate through rows
            for (int i = 1; i <= sheet1.getLastRowNum(); i++) {
                Row row = sheet1.getRow(i);
                String[] rowData = new String[row.getLastCellNum()];

                // Iterate through cells
                for (int j = 0; j < row.getLastCellNum(); j++) {
                    Cell cell = row.getCell(j, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                    cell.setCellType(CellType.STRING);
                    rowData[j] = cell.getStringCellValue();
                }

                data.add(rowData); // Add row data to the list
            }

            workbook.close();
            file.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

        return data;
    }



    /**
     * Retrieves contact data from the specified XML file.
     *
     * @param filepath the path to the XML file
     * @return a list of String arrays representing the contact data from the XML file,
     * where each array contains two elements: [0] the key and [1] the value
     * @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration requested
     */
    public static List<String[]> getDataContactDataFromXML(String filepath) throws ParserConfigurationException{
        //Each key value pair will be within an array, [0] the key, [1] the value
        List<String[]> data = new ArrayList<>();
        // Step 1: Create a DocumentBuilder
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;

        builder = factory.newDocumentBuilder();

        // Step 2: Parse the XML file and obtain the Document object
        try {
            Document document = builder.parse(new File(filepath));

            // Step 3: Use XPath to extract values from the document
            NodeList entries = document.getElementsByTagName("entry");
            for (int i = 0; i < entries.getLength(); i++) {
                Element entry = (Element) entries.item(i);
                String key = entry.getAttribute("key");
                String value = entry.getTextContent();
                data.add(new String[]{key, value});
            }
        } catch (IOException e) {
            logger.error("Error occurred while parsing XML file: {}", e.getMessage());
        } catch (org.xml.sax.SAXException e) {
            logger.error("Error occurred while parsing XML file: {}", e.getMessage());
        }



        return data;


    }

    /**
     * Retrieves data from the specified XML file. Returns a 2D array of constants values. Index[0] being "precise" and Index[1] being "estimates".
     * This function is called by the from the planets.util.PlanetaryConstants singleton class.
     *
     * @param filepath the path to the XML file
     * @return a list of String arrays representing the data extracted from the XML file,
     * where each array contains the extracted values in the order:
     * [name, hoursInDay, daysInYear, gravitationalConstant, massOfSun,
     * poundsToKilograms, kilogramsToPounds, milesToKilometers, kilometersToMiles]
     * @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration requested
     */
    public static List<String[]> getConstantsDataFromXML(String filepath) throws ParserConfigurationException {
        List<String[]> data = new ArrayList<>();
        try {
            File inputFile = new File(filepath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();

            NodeList constantList = doc.getElementsByTagName("constant");

            for (int i = 0; i < constantList.getLength(); i++) {
                Element constantElement = (Element) constantList.item(i);

                String name = constantElement.getElementsByTagName("name").item(0).getTextContent();
                String hoursInDay = constantElement.getElementsByTagName("hoursInDay").item(0).getTextContent();
                String daysInYear = constantElement.getElementsByTagName("daysInYear").item(0).getTextContent();
                String gravitationalConstant = constantElement.getElementsByTagName("gravitationalConstant").item(0).getTextContent();
                String massOfSun = constantElement.getElementsByTagName("massOfSun").item(0).getTextContent();
                String poundsToKilograms = constantElement.getElementsByTagName("poundsToKilograms").item(0).getTextContent();
                String kilogramsToPounds = constantElement.getElementsByTagName("kilogramsToPounds").item(0).getTextContent();
                String milesToKilometers = constantElement.getElementsByTagName("milesToKilometers").item(0).getTextContent();
                String kilometersToMiles = constantElement.getElementsByTagName("kilometersToMiles").item(0).getTextContent();

                // Create an array of strings representing the extracted data
                String[] rowData = {name, hoursInDay, daysInYear, gravitationalConstant, massOfSun,
                        poundsToKilograms, kilogramsToPounds, milesToKilometers, kilometersToMiles};

                data.add(rowData); // Add row data to the list
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return data;
    }

    /**
     * Creates an Excel file with the provided data.
     *
     * @param headers  The headers for the Excel sheet.
     * @param data     The data to write to the Excel sheet.
     * @param filePath The path where the Excel file should be created.
     */
    public static void createExcelFile(String[] headers, List<String[]> data, String filePath) {
        try {
            // Create a Random object
            Random random = new Random();

            // Generate a random number between 0 and 21 (inclusive)
            int randomNumber = random.nextInt(22);

            String newFileName = "SpaceJourneyResults" + randomNumber;

            // Create new Excel workbook and sheet
            @SuppressWarnings("resource")
            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("Travel Data");

            // Create headers of excel sheet
            Row headerRow = sheet.createRow(0);
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
            }

            // Write data to the Excel data cells
            for (int i = 0; i < data.size(); i++) {
                Row row = sheet.createRow(i + 1);
                String[] rowData = data.get(i);
                for (int j = 0; j < rowData.length; j++) {
                    Cell cell = row.createCell(j);
                    cell.setCellValue(rowData[j]);
                }
            }

            File file = new File(filePath + File.separator + newFileName + ".xlsx");
            file.getParentFile().mkdirs(); // Ensure parent directories exist

            // Save workbook to file
            try (FileOutputStream fileOut = new FileOutputStream(file)) {
                workbook.write(fileOut);
            }
        } catch (IOException e) {
            // Log exception using log4j
            Throwable rootCause = ExceptionUtils.getRootCause(e);
            if (rootCause != null) {
                logger.error("Root cause: " + rootCause.getMessage());
            }
            logger.error("Stack trace: " + ExceptionUtils.getStackTrace(e));
        }
    }


    public static void createExcelFile(List<String> sheetNames, List<String[]> headersList, List<List<String[]>> dataList, String filePath) {
        try {
            // Create a Random object
            Random random = new Random();

            // Generate a random number between 0 and 21 (inclusive)
            int randomNumber = random.nextInt(22);

            String newFileName = "SpaceJourneyResults" + randomNumber;

            // Create new Excel workbook
            Workbook workbook = new XSSFWorkbook();

            // Write data to each sheet
            for (int sheetIndex = 0; sheetIndex < sheetNames.size(); sheetIndex++) {
                String sheetName = sheetNames.get(sheetIndex);
                String[] headers = headersList.get(sheetIndex);
                List<String[]> data = dataList.get(sheetIndex);

                // Create sheet
                Sheet sheet = workbook.createSheet(sheetName);

                // Create headers of excel sheet
                Row headerRow = sheet.createRow(0);
                for (int i = 0; i < headers.length; i++) {
                    Cell cell = headerRow.createCell(i);
                    cell.setCellValue(headers[i]);
                }

                // Write data to the Excel data cells
                for (int i = 0; i < data.size(); i++) {
                    Row row = sheet.createRow(i + 1);
                    String[] rowData = data.get(i);
                    for (int j = 0; j < rowData.length; j++) {
                        Cell cell = row.createCell(j);
                        cell.setCellValue(rowData[j]);
                    }
                }
            }

            File file = new File(filePath + File.separator + newFileName + ".xlsx");
            file.getParentFile().mkdirs(); // Ensure parent directories exist

            // Save workbook to file
            try (FileOutputStream fileOut = new FileOutputStream(file)) {
                workbook.write(fileOut);
            }
        } catch (IOException e) {
            // Handle the exception
            e.printStackTrace();
        }
    }


    /**
     * Retrieves the name of the file.
     *
     * @return The name of the file.
     */
    @Override
    public String getFileName() {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * Reads details from the file.
     */
    @Override
    public void readDetailsFromFile() {
        // TODO Auto-generated method stub
    }
}
