/**
 *
 */
package assignment.files.xml;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.XMLEventWriter;

public abstract class AbstractXmlStaxWriteElementData {
    protected ByteArrayOutputStream byteArrayOutputStream;
    protected XMLEventFactory eventFactory;
    protected XMLEventWriter eventWriter;
    protected ArrayList<String> dataList;
    protected String xmlContent;

    public AbstractXmlStaxWriteElementData() {
        initialize();
    }

    public abstract void writeFile();

    public abstract void createXml(String group);

    public abstract void formatXML(String xml);

    public void initialize() {
        byteArrayOutputStream = new ByteArrayOutputStream();
        eventFactory = XMLEventFactory.newInstance();
        dataList = new ArrayList<>();
    }

    public ByteArrayOutputStream getByteArrayOutputStream() {
        return byteArrayOutputStream;
    }

    public void setByteArrayOutputStream(ByteArrayOutputStream byteArrayOutputStream) {
        this.byteArrayOutputStream = byteArrayOutputStream;
    }

    public ArrayList<String> getDataList() {
        return dataList;
    }

    public String getXmlContent() {
        return xmlContent;
    }

    public void openXmlStaxFactory() {
        // Open XML StAX Factory
        // Implementation specific to your requirements
    }

    public void closeXmlStaxFactory() {
        // Close XML StAX Factory
        // Implementation specific to your requirements
    }

    public void createStartParentNode() {
        // Create starting parent node
        // Implementation specific to your requirements
    }

    public void createEndParentNode() {
        // Create ending parent node
        // Implementation specific to your requirements
    }

    public void createStartChildNode(String name) {
        // Create starting child node
        // Implementation specific to your requirements
    }

    public void createEndChildNode(String name) {
        // Create ending child node
        // Implementation specific to your requirements
    }

    public void createNode(String name, String value) {
        // Create node with name and value
        // Implementation specific to your requirements
    }

    public String getChildNodeTag() {
        // Get child node tag
        // Implementation specific to your requirements
        return "";
    }

    public String getFileName() {
        // Get file name
        // Implementation specific to your requirements
        return "";
    }

    public String getFileNamePrefix() {
        // Get file name prefix
        // Implementation specific to your requirements
        return "";
    }

    public String getFileNameSuffix() {
        // Get file name suffix
        // Implementation specific to your requirements
        return "";
    }

    public String getXmlParentTag() {
        // Get XML parent tag
        // Implementation specific to your requirements
        return "";
    }

    public boolean useNameUnique() {
        // Determine if name is unique
        // Implementation specific to your requirements
        return false;
    }
}
