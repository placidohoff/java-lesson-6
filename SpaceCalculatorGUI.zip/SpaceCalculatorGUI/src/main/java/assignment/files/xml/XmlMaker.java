package assignment.files.xml;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

/**
 * Utility class for creating XML files based on provided data.
 */
public class XmlMaker {

    /**
     * Constructor for XmlMaker.
     */
    public XmlMaker() {
        // Default constructor
    }

    /**
     * Create an XML file based on provided data.
     * @param dataCellsFromJourney List containing journey data and developer contact information
     * @param exportPath The path where the XML file will be exported
     */
    public static void CreateXMLFile(List<List<String[]>> dataCellsFromJourney, String exportPath) {
        // Create elements and append them to JourneyLeg
        String[] elementNamesJourneyLeg = {"Leg", "TransportationVehicle", "StartingPlanet", "DestinationPlanet", "TravelTime", "TotalSalary", "SalaryPerCrew", "TotalFoodCost", "FoodCostPerCrewMember"};

        String[] elementNamesContactInformation = {"FirstName", "LastName", "StudentID", "Email", "Date", "Comments"};

        // Create a DocumentBuilderFactory
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = null;
        try {
            builder = factory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }

        // Create a new Document
        Document document = builder.newDocument();

        // Create root element
        Element entireJourneyElement = document.createElement("EntireJourney");
        document.appendChild(entireJourneyElement);

        // Loop through each journey leg
        for (String[] journeyData : dataCellsFromJourney.get(0)) {
            // Create JourneyLeg element
            Element journeyLegElement = document.createElement("JourneyLeg");
            entireJourneyElement.appendChild(journeyLegElement);

            // Create elements for the JourneyLeg
            for (int i = 0; i < elementNamesJourneyLeg.length && i < journeyData.length; i++) {
                Element childElement = document.createElement(elementNamesJourneyLeg[i]);
                childElement.setTextContent(journeyData[i]);
                journeyLegElement.appendChild(childElement);
            }
        }

        // Add developer's contact information to the XML
        Element contactInformationElement = document.createElement("DeveloperContactInformation");
        entireJourneyElement.appendChild(contactInformationElement);

        for (String[] devData : dataCellsFromJourney.get(1)) {
            // Create elements for the DeveloperContactInformation
            for (int i = 0; i < elementNamesContactInformation.length && i < devData.length; i++) {
                Element childElement = document.createElement(elementNamesContactInformation[i]);
                childElement.setTextContent(devData[i]);
                contactInformationElement.appendChild(childElement);
            }
        }

        // Generate a random filename
        String newFilename = exportPath + "/SpaceJourneyResultsXML" + generateRandomNumber(1, 21) + ".xml";

        // Write the content into an XML file
        try {
            javax.xml.transform.TransformerFactory.newInstance().newTransformer().transform(
                    new javax.xml.transform.dom.DOMSource(document),
                    new javax.xml.transform.stream.StreamResult(newFilename));
        } catch (TransformerConfigurationException e) {
            e.printStackTrace();
        } catch (TransformerException e) {
            e.printStackTrace();
        } catch (TransformerFactoryConfigurationError e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to generate a random number within a range.
     * @param min The minimum value of the range
     * @param max The maximum value of the range
     * @return A random integer within the specified range
     */
    private static int generateRandomNumber(int min, int max) {
        Random random = new Random();
        return random.nextInt(max - min + 1) + min;
    }
}
