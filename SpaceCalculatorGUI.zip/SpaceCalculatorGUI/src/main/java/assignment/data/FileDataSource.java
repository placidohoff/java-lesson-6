/**
 * Represents a file data source.
 */
package assignment.data;

/**
 * Specifies the operations for a file data source.
 */
public interface FileDataSource {

    /**
     * Retrieves the name of the file.
     *
     * @return The name of the file.
     */
    String getFileName();

    /**
     * Reads details from the file.
     */
    void readDetailsFromFile();
}

