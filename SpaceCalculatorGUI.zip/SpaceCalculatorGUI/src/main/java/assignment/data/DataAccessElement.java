/**
 * Specifies the behavior that should be implemented by each PlanetaryBody and TransportationVehicle.
 */
package assignment.data;

/**
 * Should be implemented by each PlanetaryBody and TransportationVehicle
 */
public interface DataAccessElement {

    /**
     * Retrieves the name of the element.
     *
     * @return The name of the element.
     */
    String getElementName();
}