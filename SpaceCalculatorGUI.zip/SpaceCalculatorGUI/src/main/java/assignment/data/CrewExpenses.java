/**
 * Specifies the behavior related to crew expenses.
 */
package assignment.data;

/**
 * Represents crew-related expenses.
 */
public interface CrewExpenses {

    /**
     * Retrieves the daily food cost per crew member.
     *
     * @return The daily food cost per crew member.
     */
    double getDailyFoodCostPerCrewMember();

    /**
     * Retrieves the daily salary per crew member.
     *
     * @return The daily salary per crew member.
     */
    double getDailySalaryPerCrewMember();
}
